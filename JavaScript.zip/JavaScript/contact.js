// Get the form and success message elements
const form = document.getElementById('contact-form');
const successMessage = document.getElementById('success-message');

// Add event listener to form submit
form.addEventListener('submit', (e) => {
    e.preventDefault();

    // Get the form data
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const query = document.getElementById('query').value;

    // Send the data to your server or email service
    // For demo purposes, we'll just log the data to the console
    console.log(`Email: ${email}, Phone: ${phone}, Query: ${query}`);

    // Show the success message
    successMessage.style.display = 'block';

    // Reset the form
    form.reset();
});