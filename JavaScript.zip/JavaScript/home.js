// Get the checkbox element
const checkbox = document.getElementById('check');

// Get the sidebar menu element
const sidebarMenu = document.querySelector('.sidebar_menu');

// Add an event listener to the checkbox
checkbox.addEventListener('click', () => {
  // Toggle the sidebar menu
  sidebarMenu.classList.toggle('active');
});

// Add an event listener to the window resize event
window.addEventListener('resize', () => {
  // Check if the window width is less than 768px
  if (window.innerWidth < 768) {
    // Add the active class to the sidebar menu
    sidebarMenu.classList.add('active');
  } else {
    // Remove the active class from the sidebar menu
    sidebarMenu.classList.remove('active');
  }
});