// Get the elements
const container = document.querySelector('.container');
const basicDiv = document.querySelector('.Basic');
const optionDiv = document.querySelector('.option');
const button = document.querySelector('button');

// Define the breakpoints
const breakpoints = {
  sm: 576, // small screen
  md: 768, // medium screen
  lg: 992, // large screen
  xl: 1200 // extra large screen
};

// Function to adjust layout based on screen size
function adjustLayout() {
  const screenWidth = window.innerWidth;

  if (screenWidth < breakpoints.sm) {
    // Small screen adjustments
    basicDiv.style.maxWidth = '90%';
    optionDiv.style.flexDirection = 'column';
    button.style.fontSize = 'small';
  } else if (screenWidth < breakpoints.md) {
    // Medium screen adjustments
    basicDiv.style.maxWidth = '80%';
    optionDiv.style.flexDirection = 'row';
    button.style.fontSize = 'medium';
  } else if (screenWidth < breakpoints.lg) {
    // Large screen adjustments
    basicDiv.style.maxWidth = '70%';
    optionDiv.style.flexDirection = 'row';
    button.style.fontSize = 'large';
  } else {
    // Extra large screen adjustments
    basicDiv.style.maxWidth = '60%';
    optionDiv.style.flexDirection = 'row';
    button.style.fontSize = 'x-large';
  }
}

// Add event listener to window resize
window.addEventListener('resize', adjustLayout);

// Call the function initially
adjustLayout();